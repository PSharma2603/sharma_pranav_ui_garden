export { default } from "./Img";
