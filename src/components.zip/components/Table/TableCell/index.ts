export { default } from "./TableCell";
