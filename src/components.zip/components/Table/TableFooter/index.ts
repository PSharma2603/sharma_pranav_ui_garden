export { default } from "./TableFooter";
