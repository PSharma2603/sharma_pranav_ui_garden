export { default } from "./HeroImage";
