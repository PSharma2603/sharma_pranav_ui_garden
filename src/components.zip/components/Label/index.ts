export { default } from "./Label";
