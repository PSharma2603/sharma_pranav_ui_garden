export { default } from "./Text";
